package com.gamingroom;



/**
 * Application start-up program
 * 
 * @author coce@snhu.edu
 */
public class ProgramDriver {
	
	/**
	 * The one-and-only main() method
	 * 
	 * @param args command line arguments
	 */
	public static void main(String[] args) {
		
		GameService service = GameService.getInstance();
		
		System.out.println("\nAbout to test initializing game data...");
		
		// initialize with some game data
		Game game1 = service.addGame("Game #1");
		System.out.println(game1);
		Game game2 = service.addGame("Game #2");
		System.out.println(game2);
		
		// initialize with some team data
		game1.addTeam("G1team1");
		game1.addTeam("G1team2");
		game1.teams.get(0).addPlayer("G1Team1Player1");
		game1.teams.get(0).addPlayer("G1Team1Player2");
		game1.teams.get(1).addPlayer("G1Team2Player1");
		game1.teams.get(1).addPlayer("G1Team2Player2");
		
		game2.addTeam("G2team1");
		game2.addTeam("G2team2");
		game2.teams.get(0).addPlayer("G2Team1Player1");
		game2.teams.get(0).addPlayer("G2Team1Player2");
		game2.teams.get(1).addPlayer("G2Team2Player1");
		game2.teams.get(1).addPlayer("G2Team2Player2");
		
				
		
		
		
		// use another class to prove there is only one instance
		SingletonTester tester = new SingletonTester();
		tester.testSingleton();
	}
}
