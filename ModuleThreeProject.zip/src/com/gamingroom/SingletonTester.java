package com.gamingroom;

/**
 * A class to test a singleton's behavior
 * 
 * @author coce@snhu.edu
 */



//This singleton pattern is used in a design where a class may only have one global instance of itself.  This is used in cases where more than one instance can cause errors in data.
//In this case, the GameService class is the global class.  In this class, it stores a dynamic array of games.  The games hold information about games in their class.  
//The SingletonTester holds the main method.  The gameService is called by GameService.gameService.
//This is much like built in libraries.  The biggest example of this design pattern is the Math library.  It's methods are called in by referencing the global Math.



//The addGame and getGame methods in the GameService class iterate through the static games array list.  These methods are designed to see if an instance of a game exists in the array list.
//If the addGame is called, it will add the game to the list if the instance is not found, or it will return the instance itself if it is found, and the instance is not added to the list.
//These methods can accessed by calling only when an instance of GameService is created.  If these methods were static, then they could be called by calling the class itself, not the instance.  GameService.STATICMETHOD()
//This can be used to parse through data that's sent to the method when called without having to create an instance of the static class file made.















public class SingletonTester {

	public void testSingleton() {
		
		System.out.println("\nAbout to test the singleton...");
	
		GameService service = GameService.getInstance(); // replace null with ???
		
		// a simple for loop to print the games
		for (int i = 0; i < service.getGameCount(); i++) {
			System.out.println(service.getGame(i));
			
			for(int x = 0; x < service.getGame(i).teams.size(); x++) {
				System.out.println(service.getGame(i).teams.get(x));
				
				for(int z = 0; z < service.getGame(i).teams.get(x).players.size(); z++) {
					System.out.println(service.getGame(i).teams.get(x).players.get(z));
				}
			}
			
			System.out.println();
		}

	}
	
}
